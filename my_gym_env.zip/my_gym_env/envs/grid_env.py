import gym
from gym import spaces
import numpy as np
import pygame
import time

class GridEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 4}

    def __init__(self, render_mode=None, size=100):
        print("Initializing GridEnv...")
        self.size = size
        self.window_size = 1000 # pygame window resolution

        self.observation_space = spaces.Dict(
            {
                "agent": spaces.Box(0, size - 1, shape=(2,), dtype=int),
                "target": spaces.Box(0, size - 1, shape=(2,), dtype=int),
            }
        )

        self.action_space = spaces.Discrete(2)  # Only Up and Right allowed

        self._action_to_direction = {
            0: np.array([0, 1]),  # Right (→)
            1: np.array([-1, 0]), # Up (↑)
        }

        self.render_mode = render_mode
        self.window = None
        self.clock = None
        self.path = []  # Track agent's path
        print("GridEnv initialized.")

    def reset(self, seed=None, options=None):
        self.agent_pos = np.array([self.size - 1, 0])  # Start at bottom-left
        self.target_pos = np.array([0, self.size - 1])  # Target at top-right
        self.path = [tuple(self.agent_pos)]  # Initialize path with starting position
        return {"agent": self.agent_pos, "target": self.target_pos}, {}

    def step(self, action):
        direction = self._action_to_direction[action]
        self.agent_pos = np.clip(self.agent_pos + direction, 0, self.size - 1)

        self.path.append(tuple(self.agent_pos))  # Store the path

        done = np.array_equal(self.agent_pos, self.target_pos)
        reward = 1 if done else -0.1

        time.sleep(2)
        return {"agent": self.agent_pos, "target": self.target_pos}, reward, done, False, {}

    def render(self):
        if self.render_mode == "human":
            if self.window is None:
                pygame.init()
                self.window = pygame.display.set_mode((self.window_size, self.window_size))
                self.clock = pygame.time.Clock()

            self.window.fill((255, 255, 255))
            cell_size = self.window_size // self.size

            # Symbols in Grid Cells
            symbols = {
                (7, 2): "📖",  
                (6, 3): "📖",  
                (5, 3): "✏️",
                (4, 4): "📖",
                (3, 5): "✏️",
                (2, 6): "✏️",
                (1, 7): "📖",  
            }

            # Load Font (Unicode-Supported)
            font_path = "fonts/NotoEmoji-Bold.ttf"
            try:
                font = pygame.font.Font(font_path, 32)
            except:
                font = pygame.font.Font(None, 32) 

            for x in range(self.size):
                for y in range(self.size):
                    rect = pygame.Rect(x * cell_size, y * cell_size, cell_size, cell_size)
                    pygame.draw.rect(self.window, (200, 200, 200), rect, 1)

                    # Displaying proficiency levels
                    level_font = pygame.font.Font(None, 24)
                    level_text = level_font.render(f"Lvl {self.size - y}", True, (0, 0, 0))
                    self.window.blit(level_text, (x * cell_size + 5, y * cell_size + 5))

                    # Displaying symbols
                    if (y, x) in symbols:  
                        text = font.render(symbols[(y, x)], True, (0, 0, 0))  # Black symbol
                        text_rect = text.get_rect(center=(x * cell_size + cell_size // 2, y * cell_size + cell_size // 2))
                        self.window.blit(text, text_rect)

            # Drawing the agent's path in green
            for pos in self.path:
                path_rect = pygame.Rect(
                    pos[1] * cell_size, pos[0] * cell_size, cell_size, cell_size
                )
                pygame.draw.rect(self.window, (0, 255, 0), path_rect)  # Green path
            
            # Drawing the agent in blue
            agent_rect = pygame.Rect(
                self.agent_pos[1] * cell_size, self.agent_pos[0] * cell_size, cell_size, cell_size
            )
            pygame.draw.rect(self.window, (0, 0, 255), agent_rect)

            # Changing Target Color to Green if Reached
            target_color = (0, 255, 0) if np.array_equal(self.agent_pos, self.target_pos) else (255, 0, 0)
            target_rect = pygame.Rect(
                self.target_pos[1] * cell_size, self.target_pos[0] * cell_size, cell_size, cell_size
            )
            pygame.draw.rect(self.window, target_color, target_rect)

            pygame.display.flip()
            self.clock.tick(self.metadata["render_fps"])

    def close(self):
        if self.window is not None:
            pygame.quit()
            self.window = None
