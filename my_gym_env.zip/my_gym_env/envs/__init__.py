from gym.envs.registration import register

register(
    id="GridEnv-v0",  # Ensure this ID matches the one used in test_env.py
    entry_point="my_gym_env.envs.grid_env:GridEnv",
)
