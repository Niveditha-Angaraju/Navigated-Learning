from gym.envs.registration import register

# Ensure the custom environment is registered when the package is imported
import my_gym_env.envs
