import gym
import my_gym_env  # Import the registered environment

env = gym.make("GridEnv-v0", render_mode="human")
obs, _ = env.reset()

print("Initial Observation:", obs)

done = False
while not done:
    action = env.action_space.sample()  # Random action
    obs, reward, done, _, _ = env.step(action)
    print(f"Action: {action}, Observation: {obs}, Reward: {reward}")
    env.render()

env.close()
